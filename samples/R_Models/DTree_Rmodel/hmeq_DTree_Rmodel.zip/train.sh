Rscript training.r

